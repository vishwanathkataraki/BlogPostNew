package blog.services;

public interface LoginService {
    boolean authentice(String username, String password);
}
